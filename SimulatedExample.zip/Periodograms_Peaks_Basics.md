# Times Series Methods for the Analysis of Soundscapes and Other Cyclical Ecological Data 

## Notebook 2 - simulations
In this notebook, we demonstrate how to reconstruct waveforms from phases and amplitudes extracted from periodograms, before modulus-squaring. For this example we use simulated data. For more information, please refer to the corresponding article, submitted to Methods in Ecology and Evolution (2024). 




### Preliminaries

Begin by loading packages and setting up directories in which to save the figures and outputs.


```R
## Load multitaper package
library('multitaper')

## Specify the directory (replace as appropriate)
figdir = "~/" 

## Set plot window size
options(jupyter.plot_scale=1)
```

#### Create the function for creating a Fourier series using amplitude and phase values for a given time frame


```R
## Set the seed for the random number generator
set.seed(123) 

## Specify function
fourierSeries <- function(amps, phases, N, numfreqs, tim) { 
    cos(2*pi*kronecker(matrix(1,N,1), t(seq(1,numfreqs)))*kronecker(matrix(1,1,numfreqs), tim) + kronecker(matrix(1,N,1), t(phases)))  %*% amps
}
```

## Create simulated time series
Specify desired time series parameters


```R
#a0          <- 1
numfreqs    <- 3                                                # The number of frequencies in the waveform
fpeaks      <- seq(1, numfreqs)                                 # Vector for frequency peaks
amps        <- rnorm(numfreqs) + 2.5                            # Vector for the amplitude/strength of each frequency peak
phases      <- rnorm(3)*pi/4                                    # The phase for each frequency peak
numdays     <- 7                                                # The length of the time series in days
sampsperday <- 60*24                                            # The number of sampling points per day (e.g. 1 per minute)
N           <- numdays*sampsperday                              # The total number of sampling points
t           <- seq(from = 0, to = N-1, by = 1)/sampsperday      # Vector for each sampling point in time
sigma       <- abs(rnorm(1))                                    # For simulating noise

## Check values
print(amps)
print(phases)
print(N)
print(sigma)
```

    [1] 1.939524 2.269823 4.058708
    [1] 0.05537716 0.10154235 1.34700889
    [1] 10080
    [1] 0.4609162
    

#### Create waveform


```R
fs = fourierSeries(amps, phases, N, numfreqs, t) 

```

#### Simulate and add white noise for each point in the series


```R
x = fs + sigma*rnorm(N)
```

#### Visualize the waveform 


```R
#png(paste(figdir, "FS_waveform.png", sep=""))
par(bg = "white")
plot(seq(1,N)/(24*60), fs, type='l', xlab='day', main="Fourier series waveform")
#dev.off()
```


    
![png](output_12_0.png)
    


### Examining the time series
Once we have our time series, we can work backwards to determine what frequencies dominate the variance. To do this, we use nonparametric spectral analysis to calculate the power spectrum for the series in the frequency domain:


```R
Spec <- 2*fft(x)/N                                             # compute the Fast Fourier Transform of the signal 
freq <- seq(from = 0, to = 1, length.out = N+1)*sampsperday    # vector for the frequency values corresponding to the FFT
```

#### Plot the power spectrum for 12 cycles per day (cyc/d)


```R
#png(paste(figdir, "FS_waveform.png", sep=""))
plot(freq[1:N], abs(Spec)**2, log='y', type='l', xlim=c(0,12),
     main = 'Periodogram', xlab = 'frequency (cyc/d)', ylab = 'Spectrum')
#dev.off()
```


    
![png](output_16_0.png)
    


*As expected, we can see three clear peaks at 1 cyc/d, 2 cyc/d, and 3 cyc/d. For each of these peaks we can estimate magnitude and phase:* 

#### Create matrices to store information for estimated magnitude and phase


```R
emag   <- matrix(0,numfreqs)   # Magnitude
ephase <- matrix(0,numfreqs)   # Phase
cplex  <- matrix(0,numfreqs)   # Complex value
ind    <- matrix(0,numfreqs)   # Index
```

#### For each frequency, populate the matrices


```R
for (i in fpeaks){
    ind[i] = sum(freq <= fpeaks[i])
    cplex[i] = Spec[ind[i]]
    emag[i] = abs(cplex[i])
    ephase[i] = atan2((Im(cplex[i])), Re(cplex[i]))*180/pi
}
```

#### Print values for the estimated and true magnitude, and for the estimated and true values for phase for the first three cyc/d based on the periodogram: 


```R
paste("Periodogram Estimated magnitude:", round(emag,6), "and True Magnitude:", round(amps,6), "for", fpeaks, "cyc/d.") 
paste("Periodogram Estimated phase:", round(ephase,6), "degrees and True Phase:", round(180*phases/pi,6), "degrees for", fpeaks, "cyc/d.") 
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'Periodogram Estimated magnitude: 1.949472 and True Magnitude: 1.939524 for 1 cyc/d.'</li><li>'Periodogram Estimated magnitude: 2.269899 and True Magnitude: 2.269823 for 2 cyc/d.'</li><li>'Periodogram Estimated magnitude: 4.053606 and True Magnitude: 4.058708 for 3 cyc/d.'</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'Periodogram Estimated phase: 3.178058 degrees and True Phase: 3.172878 degrees for 1 cyc/d.'</li><li>'Periodogram Estimated phase: 5.699835 degrees and True Phase: 5.817948 degrees for 2 cyc/d.'</li><li>'Periodogram Estimated phase: 77.077531 degrees and True Phase: 77.177924 degrees for 3 cyc/d.'</li></ol>



*We can see the estimates closely resembled the true values for both magnitude and phase*

## Compute and plot multitaper spectrum estimates
Specify settings - see https://www.rdocumentation.org/packages/multitaper/versions/1.0-15/topics/spec.mtm


```R
nw = 2.5        # a positive double precision number, the time-bandwidth parameter
k  = 4          # the number of tapers, often 2*nw
```

#### Compute the spectrum


```R
mtsp = spec.mtm(as.ts(x), nw=nw, k=k, returnInternals=TRUE, nFFT=2*N, centre='none', plot=FALSE)
```

#### Create matrices to store information for estimated magnitude and phase for the multitaper


```R
mtmag   = matrix(0,numfreqs)
mtphase = matrix(0,numfreqs)
mtcplex = matrix(0,numfreqs)

scale   = nw/sqrt(N)
```

#### For each frequency, populate the matrices 


```R
for (i in seq(1,numfreqs)){
    ind[i] = sum(mtsp$freq*sampsperday <= fpeaks[i])
    mtcplex[i] = mtsp$mtm$eigenCoefs[ind[i],1]
    mtmag[i] = abs(mtcplex[i])*scale
    mtphase[i] = atan2((Im(mtcplex[i])), Re(mtcplex[i]))*180/pi
}
```

#### Print values for the estimated and true magnitude, and for the estimated and true values for phase for the first three cyc/d based on the multitaper spectrum analysis: 


```R
paste("MT Estimated magnitude:", round(mtmag,6), "and True Magnitude:", round(amps,6), "for", fpeaks, "cyc/d.") 
paste("MT Estimated phase:", round(mtphase,6), "degrees and True Phase:", round(180*phases/pi,6), "degrees for", fpeaks, "cyc/d.") 
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'MT Estimated magnitude: 1.910197 and True Magnitude: 1.939524 for 1 cyc/d.'</li><li>'MT Estimated magnitude: 2.228536 and True Magnitude: 2.269823 for 2 cyc/d.'</li><li>'MT Estimated magnitude: 3.968998 and True Magnitude: 4.058708 for 3 cyc/d.'</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'MT Estimated phase: 3.212961 degrees and True Phase: 3.172878 degrees for 1 cyc/d.'</li><li>'MT Estimated phase: 5.704314 degrees and True Phase: 5.817948 degrees for 2 cyc/d.'</li><li>'MT Estimated phase: 77.177661 degrees and True Phase: 77.177924 degrees for 3 cyc/d.'</li></ol>



#### Plot the periodogram and multitaper spectrum up to 12 cyc/d


```R
#png(paste(figdir, "MT_Pgram_sim.png", sep=""))
plot(freq[1:N], abs(Spec)**2, log='y', type='l', xlim=c(0,12),
     main = 'Periodogram vs Multitaper Spectrum', xlab = 'Frequency (cyc/d)', ylab = 'Spectrum')
lines(mtsp$freq*sampsperday, mtsp$spec/N, col = 'red')#, type = 'l', log='y', xlim=c(0,12))
lines(mtsp$freq[ind]*sampsperday, mtsp$spec[ind]*nw/sqrt(N))
legend('topright', pch=16, legend=c("P", "MT"), col = c("black", "red"))
#dev.off()
```


    
![png](output_36_0.png)
    


*We can see all the information for the waveform is captured in the first three cyc/d*

## Sanity check for the PCA

#### Create 3 waveforms with the same underlying waveform (fs) but different noise amplitudes


```R
y = fs + 2*rnorm(N)
z = fs + fourierSeries(amps/2, phases, N, numfreqs, t)  + 3*rnorm(N)
```

#### Plot to visualise 3 waveforms


```R
png(paste(figdir, "/Simulated_Data.png", sep=""))

par(mfrow=c(3,1), mgp = c(2,0.6, 0), mar=c(4, 4, 2, 2), las=1)
plot(t, x, type = 'l', xlab="", cex.lab=2, cex.axis=1.4)
plot(t, y, col = 2, type = 'l', xlab="", cex.lab=2, cex.axis=1.4)
plot(t, z, col = 3, type = 'l', cex.lab=2, cex.axis=1.4)
dev.off()

pdf(paste(figdir, "/Simulated_Data.pdf", sep=""))

par(mfrow=c(3,1), mgp = c(2,0.6, 0), mar=c(4, 4, 2, 2), las=1)
plot(t, x, type = 'l', xlab="", cex.lab=2, cex.axis=1.4)
plot(t, y, col = 2, type = 'l', xlab="", cex.lab=2, cex.axis=1.4)
plot(t, z, col = 3, type = 'l', cex.lab=2, cex.axis=1.4)
dev.off()
```


<strong>png:</strong> 2



<strong>png:</strong> 2


*We can see the first waveform has the least noise, the second has more noise, and the third has the most noise. Note that the amplitude of the waveform is also 1.5x for the third*

#### Specify multitaper settings


```R
nseries = 3 # the number of waveforms to assess
nw      = 2 # the time-bandwidth parameter, which has been set smaller than the default value to show detai
k       = 4 # the number of tapers, often 2*nw
```

#### Add unique anomalies to the to the data and standardize the time series to have zero mean and unit variance


```R
x_anomaly = (x - mean(x))/sd(x)
y_anomaly = (y - mean(y))/sd(x)
z_anomaly = (z - mean(z))/sd(x)
```

#### Compute the spectrum for the three waveforms x,y, and z


```R
mts1 = spec.mtm(as.ts(x_anomaly), returnInternals = TRUE, nw=nw, k = k, plot=FALSE)
mts2 = spec.mtm(as.ts(y_anomaly), returnInternals = TRUE, nw=nw, k = k, plot=FALSE)
mts3 = spec.mtm(as.ts(z_anomaly), returnInternals = TRUE, nw=nw, k = k, plot=FALSE)
```

#### Plot the multitaper spectrum for the three waveforms


```R
#png(paste(figdir, "MT_Sim_data.png", sep=""))

plot(mts1$freq*sampsperday, mts1$spec, log="y", type="l", 
     xlim=c(0,12), ylim = c(1e-3, 5e3), col = 1, ylab = " MT Spectrum",
    xlab = "Frequency (cyc/d)")
lines(mts2$freq*sampsperday, mts2$spec, col = 2)
lines(mts2$freq*sampsperday, mts3$spec, col = 3)
legend('topright', pch=16, legend=c("x", "y", "z"), col = seq(1,3))
#dev.off()
```


    
![png](output_51_0.png)
    



```R
png(paste(figdir, "/MT_Sim_data.png", sep=""))
# par(mar = c(3,3, 0.2, 0.2), mgp = c(0.2, 1, 0), xpd=FALSE, las=1, cex.axis=1) #, cin=c(3.5,7))
par(mgp = c(2, 0.6, 0), cex.axis=1, cex=1.2) #, cin=c(3.5,7))
plot(mts1$freq*sampsperday, mts1$spec, log="y", type="l", 
     xlim=c(0,12), ylim = c(1e-3, 5e3), col = 1, ylab = " MT Spectrum",
    xlab = "Frequency (cyc/d)")
lines(mts2$freq*sampsperday, mts2$spec, col = 2)
lines(mts2$freq*sampsperday, mts3$spec, col = 3)
legend('topright', pch=16, legend=c("x", "y", "z"), col = seq(1,3))

axis(1, at = seq(0, 12, by = 1), labels = seq(0, 12, by = 1))

dev.off()
```


<strong>png:</strong> 2


*As we can see, each of the 3 waveforms share very similar peaks at 1, 2, and 3 cyc/d with a lack of peaks after 4+ cyc/d. Peak width is also equal across the waveforms and the noise level for y is larger than that of x so the baseline average for the spectrum is larger. We can see the variance is higher in z than x or y which represents the noise we introduced.*  

Now, we can work backwards to find the common waveform which we know to be "fs"

## Find the common waveform 
#### Calculate the PCA


```R
nfft = length(mts1$mtm$eigenCoefs[,1])
u = array(0, dim=c(k, nseries, nfft))
v = array(0, dim=c(nseries, nseries, nfft))
d = array(0, dim=c(nseries, nfft))
for (ff in seq(1, nfft)){
  ecof = svd(cbind(mts1$mtm$eigenCoefs[ff,], mts2$mtm$eigenCoefs[ff,], mts3$mtm$eigenCoefs[ff,]))
  u[,,ff] = ecof$u
  v[,,ff] = ecof$v
  d[,ff] = ecof$d
}
```

#### Plot PCA for 12 cycles/d


```R
png(paste(figdir, "/Simulation_SVD.png", sep=""))
par(mgp = c(2.5, 0.6, 0), cex.axis=1, cex=1.2, las=1) #, cin=c(3.5,7))

plot(mts1$freq*60*24, d[1,], type='l',ylab="Power spectrum",
       xlab="Frequency (cyc/d)",log = "y", xlim = c(0, 12),
       ylim = c(1e-1, 2e2), 
       main = "PCA as a function of frequency",
       col = "#000080", lty=1)
lines(mts1$freq*60*24, d[2,], col = "#000080",lty=2)
lines(mts1$freq*60*24, d[3,], col = "#000080", lty=3)
#lines(c(-nw,nw)*(24*60)/duration[1]+1, 5e4*c(1,1), col=4)
legend('topright', legend=c("First","Second","Third"), col=c("#000080","#000080","#000080"),lty = c(1, 2, 3))

axis(1, at = seq(0, 12, by = 1), labels = seq(0, 12, by = 1))
axis(2, at = c(0.1, 0.5, 5, 50), labels = c("0.1", "0.5", "5.0", "50.0"))

dev.off()



pdf(paste(figdir, "/Simulation_SVD.pdf", sep=""))
par(mgp = c(2.5, 0.6, 0), cex.axis=1, cex=1.2, las=1) #, cin=c(3.5,7))

plot(mts1$freq*60*24, d[1,], type='l',ylab="Power spectrum",
       xlab="Frequency (cyc/d)",log = "y", xlim = c(0, 12),
       ylim = c(1e-1, 2e2), 
       main = "PCA as a function of frequency",
       col = "#000080", lty=1)
lines(mts1$freq*60*24, d[2,], col = "#000080",lty=2)
lines(mts1$freq*60*24, d[3,], col = "#000080", lty=3)
#lines(c(-nw,nw)*(24*60)/duration[1]+1, 5e4*c(1,1), col=4)
legend('topright', legend=c("First","Second","Third"), col=c("#000080","#000080","#000080"),lty = c(1, 2, 3))

axis(1, at = seq(0, 12, by = 1), labels = seq(0, 12, by = 1))
axis(2, at = c(0.1, 0.5, 5, 50), labels = c("0.1", "0.5", "5.0", "50.0"))
axis(2, at = c(0.1, 0.5, 5, 50), labels = c("0.1", "0.5", "5.0", "50.0"))

dev.off()
```


<strong>png:</strong> 2



<strong>png:</strong> 2


Plot interpretation:
- PCA Axis 1 - wide peak widths, peaks clearly aligned at 1-3 cyc/d
- PCA Axis 2 - no peaks, no relationship, but also essentially flat except for statistical variation, which is what the spectrum looks like for white noise. 
- PCA Axis 3 - no peaks, no relationship, but also essentially flat except for statistical variation, which is what the spectrum looks like for white nois

*Note: the first principal component vector encapsulates all of the waveform that we had injected originally and only white noise remains in the second and third principal components.The order of magnitude difference between the axes reflects the fact that the proportion of variance that the first principal component vector represents is much larger than that of the second (and the second than that of the third.)*
